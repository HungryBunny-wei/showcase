// module.exports = {
//   watchDirs: {
//     entity: {
//       path: 'app/entity', // dir path
//       // pattern: '**/*.(ts|js)', // glob pattern, default is **/*.(ts|js). it doesn't need to configure normally.
//       generator: 'class', // generator name
//       framework: 'meiyoucar', // framework name
//       interface: 'IEntity',  // interface name
//       caseStyle: 'upper', // caseStyle for loader
//       interfaceHandle: val => `${val}.${val}`, // interfaceHandle
//     trigger: ['add', 'unlink'], // recreate d.ts when receive these events, all events: ['add', 'unlink', 'change']
//   }
// }
// }