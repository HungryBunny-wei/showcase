function MeiCar() {

}

MeiCar.prototype.getCsrf = function () {
  var keyValue = document.cookie.match('(^|;) ?csrfToken=([^;]*)(;|$)');
  return keyValue ? keyValue[2] : null;
}
MeiCar.prototype.login = function (phone, password) {
  layui.use(['layer'], () => {
    let layer = layui.layer
      , $ = layui.jquery;
    $.ajax({
      url: '/api/user/login',
      data: {
        Phone: phone,
        Password: password,
      },
      method: 'POST',
      // contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
      // processData: false, // NEEDED, DON'T OMIT THIS
      success: function (result) {
        window.localStorage.setItem('meiyou.session', result.session.id);
        window.location.href = './index.html';
      },
      error: function (responseStr, a) {
        console.log(responseStr);
        layer.alert(responseStr.responseJSON.message, {
          title: '登录失败'
        });
      }
    });
  });
}
MeiCar.prototype.getPostHeader = function () {
  let result = {
    'X-WX-Id': window.localStorage.getItem('meiyou.session'),
    'X-WX-Skey': 'bravo',
  }
  if(!result['X-WX-Id']){
    window.location.href = './login.html';
  }
  return result;
}
MeiCar.prototype.userAddManage = function (data, call) {
  layui.use(['layer'], () => {
    let layer = layui.layer
      , $ = layui.jquery;
    $.ajax({
      url: '/api/manage/user/manage?_csrf=' + this.getCsrf(),
      data: data,
      headers: this.getPostHeader(),
      method: 'POST',
      success: function (result) {
        call(result);
      },
      error: function (responseStr, a) {
        console.log(responseStr);
        layer.alert(responseStr.responseJSON.message, {
          title: '提交失败'
        });
      }
    });
  })
}
MeiCar.prototype.post = function (url, body) {
  $.ajax({
    url: '/api/user/login',
    data: {
      _csrf: this.getCsrf(),
      Phone: phone,
      Password: password,
    },
    method: 'POST',
    // contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
    // processData: false, // NEEDED, DON'T OMIT THIS
    success: function (result) {
      window.localStorage.setItem('meiyou.session', result.session.id);
      window.location.href = './main.html';
    },
    error: function (responseStr, a) {
      console.log(responseStr);
      alert("登录失败: " + responseStr.responseJSON.message);
    }
  });
}

window.meiCar = new MeiCar();