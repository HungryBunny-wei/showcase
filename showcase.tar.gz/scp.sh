scp /home/wei/Desktop/workspace/meiyou-car/showcase/showcase.tar.gz root@120.77.240.193:/opt/rabbit
